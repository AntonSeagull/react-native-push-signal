# react-native-push-signal

English | [Русский](README.ru.md)

Get device credentials for your server and listen for incoming notifications or taps. The library does not send pushes — your backend talks to APNs and FCM. Request notification permission yourself with [`react-native-permissions`](https://github.com/zoontek/react-native-permissions).

## Installation

```sh
npm install react-native-push-signal
```

## Usage

```ts
import {
  checkNotifications,
  requestNotifications,
  RESULTS,
} from 'react-native-permissions';
import {
  getCredentials,
  initialize,
  onMessage,
  onNotificationPress,
} from 'react-native-push-signal';

await initialize({
  project_id: 'my-project',
  mobilesdk_app_id: '1:123456789:android:abcd',
  current_key: 'AIza...',
  project_number: '123456789',
});

const { status } = await checkNotifications();
if (status !== RESULTS.GRANTED) {
  await requestNotifications(['alert', 'badge', 'sound']);
}

const credentials = await getCredentials();
// POST credentials to your server: { token, environment? }

const stopMessages = onMessage((message) => {
  console.log('incoming', message);
});

const stopPress = onNotificationPress((message) => {
  console.log('opened from notification', message);
});
```

`onNotificationPress` also delivers the tap that launched the app if you subscribe after startup.

### What to send to your server

| Platform | `credentials.token` | Server sends through |
| --- | --- | --- |
| iOS | APNs device token (hex) | Apple APNs HTTP/2 |
| Android | FCM registration token | Firebase Cloud Messaging HTTP v1 |

Keep Apple `.p8` keys and the Firebase service account on the server. The app never sees them.

`environment` is iOS-only: `sandbox` for development builds, `production` for TestFlight / App Store.

## iOS setup

1. Enable **Push Notifications** on the app target.
2. Enable **Background Modes → Remote notifications**.
3. Use a physical device. The simulator cannot register with APNs.

The library hooks `UNUserNotificationCenter` at launch (before JS starts) and APNs token callbacks, so the host `AppDelegate` does not need extra code. Foreground pushes only reach JS if this delegate is installed before launch finishes.

## Android setup

Remote Android pushes go through FCM. You can either pass the client Firebase fields at runtime or use `google-services.json`.

### Runtime config (no file in the APK)

Call `initialize` with values from `google-services.json` (not a service account):

```ts
await initialize({
  project_id: '...',
  mobilesdk_app_id: '...',
  current_key: '...',
  project_number: '...',
});
```

All four fields are required for Firebase to start. If any is missing, `initialize` resolves and does nothing. iOS ignores the config and still resolves the promise.

Keep the Firebase service account on your server. Do not put it in the app.

### google-services.json

Alternatively, add Firebase to the host app:

1. Place `google-services.json` in `android/app`.
2. Apply the Google Services plugin in `android/app/build.gradle`:

```gradle
apply plugin: "com.google.gms.google-services"
```

3. Add the plugin classpath in `android/build.gradle` / `settings.gradle` as in the [Firebase Android setup](https://firebase.google.com/docs/android/setup).

Without `initialize(...)` or that file, `getCredentials()` throws.

If the host app already declares its own `FirebaseMessagingService`, only one service can handle `com.google.firebase.MESSAGING_EVENT`. Prefer this library’s service or forward events into it.

### When it fails on Xiaomi: `SERVICE_NOT_AVAILABLE`

If `getCredentials()` throws `Failed to get an FCM token: SERVICE_NOT_AVAILABLE`, the FCM token could not be obtained. Your server never receives a token, so there is nowhere to send pushes — delivery itself is not the problem.

Before requesting the token the library checks Google Play services and retries a few times with backoff, but some causes can only be fixed on the device:

- **Google account.** The device must be signed into a Google account. FCM does not issue a token without one.
- **Google Play services.** They must be installed, enabled and up to date. On a China-only ROM without GMS, FCM cannot work at all — you need another push provider; see [Detecting a non-Google device](#detecting-a-non-google-device-getdiagnostics-and-pushsignalerror).
- **Network.** Check connectivity and disable VPN and private DNS.
- **MIUI / HyperOS.** Enable autostart and remove battery restrictions: Settings → Apps → your app → Autostart; Battery → No restrictions. Allow background data for the app.

What to look for in the logs:

```sh
adb logcat | grep -iE "SERVICE_NOT_AVAILABLE|FirebaseMessaging|PushSignal"
```

### Detecting a non-Google device: `getDiagnostics()` and `PushSignalError`

When Google Play services cannot serve FCM, the library detects it and tells you which service to use instead — both in the error message and as structured data, so the cause is visible in React Native logs.

`initialize()` and `getCredentials()` reject with `PushSignalError`:

```ts
import { getCredentials, PushSignalError } from 'react-native-push-signal';

try {
  const credentials = await getCredentials();
} catch (error) {
  if (error instanceof PushSignalError) {
    console.warn(error.code); // E_GMS_MISSING, E_FCM_TOKEN, ...
    console.warn(error.message); // "... Use HMS Push Kit (Huawei Push) instead of the standard Google service."
    console.warn(error.provider); // 'hms'
    console.warn(error.hint); // actionable sentence
    console.warn(error.diagnostics); // full device/provider snapshot
  }
}
```

You can also inspect diagnostics without requesting a token:

```ts
import { getDiagnostics } from 'react-native-push-signal';

const diagnostics = await getDiagnostics();
// { platform, gmsAvailable, gmsStatus, manufacturer, brand, model,
//   provider, providerName, providerInstalled?, hint? }
```

Provider suggested when GMS is unavailable:

| Manufacturer                | `provider`   | Service                                 |
| --------------------------- | ------------ | --------------------------------------- |
| HUAWEI / HONOR              | `hms`        | HMS Push Kit (Huawei Push)              |
| Xiaomi / Redmi / POCO       | `mi_push`    | Mi Push (Xiaomi Push)                   |
| OPPO / OnePlus / realme     | `oppo_push`  | OPPO Push (HeyTap)                      |
| vivo / iQOO                 | `vivo_push`  | vivo Push                               |
| Meizu                       | `meizu_push` | Meizu Push                              |
| anything else               | `unknown`    | generic “use another provider”          |

`providerInstalled` is `true` only when the provider service app was positively found on the device (`com.huawei.hwid`, `com.xiaomi.xmsf`); otherwise it is omitted. iOS always reports `provider: 'apns'`. The library never logs for you — pass the data wherever you need.

Error codes: `E_GMS_MISSING`, `E_GMS_DISABLED`, `E_GMS_UPDATE_REQUIRED`, `E_GMS_INVALID`, `E_GMS_UNAVAILABLE`, `E_FCM_TOKEN`, `E_FIREBASE_CONFIG`, `E_NOT_INITIALIZED`.

## Incoming messages vs taps

| App state | iOS | Android (notification payload) | Android (data-only) |
| --- | --- | --- | --- |
| Foreground | `onMessage` + system banner | `onMessage` + tray (if title/body) | `onMessage` + tray (if title/body) |
| Background / killed | System banner. Tap → `onNotificationPress` | System banner. Tap → `onNotificationPress` | No banner. `onMessage` if the process is alive |

- `onMessage` — the push arrived while the app is in the foreground (and Android data messages while the process is alive). Listeners only receive the payload; they do not control the banner.
- `onNotificationPress` — the user opened the notification, including a cold start.
- On iOS, a visible push received in the background or when the app is killed is delivered on tap, not through `onMessage`. That is an OS limit.

## Web

`initialize()` resolves. `getCredentials()` throws. Listeners (`onMessage`, `onNotificationPress`) are no-ops.

## Contributing

- [Development workflow](CONTRIBUTING.md#development-workflow)
- [Sending a pull request](CONTRIBUTING.md#sending-a-pull-request)
- [Code of conduct](CODE_OF_CONDUCT.md)

## License

MIT
