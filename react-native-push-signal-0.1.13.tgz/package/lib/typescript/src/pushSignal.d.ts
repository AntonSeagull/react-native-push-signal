import type { AndroidFirebaseConfig, OnMessageListener, PushCredentials, PushDiagnostics, PushMessage } from './types.js';
export declare function initialize(_config?: AndroidFirebaseConfig): Promise<void>;
export declare function getCredentials(): Promise<PushCredentials>;
export declare function getDiagnostics(): Promise<PushDiagnostics>;
export declare function onMessage(_listener: OnMessageListener): () => void;
export declare function onNotificationPress(_listener: (message: PushMessage) => void): () => void;
//# sourceMappingURL=pushSignal.d.ts.map