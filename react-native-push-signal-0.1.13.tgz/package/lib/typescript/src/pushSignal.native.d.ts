import type { AndroidFirebaseConfig, OnMessageListener, PushCredentials, PushDiagnostics, PushMessage } from './types.js';
export declare function initialize(config?: AndroidFirebaseConfig): Promise<void>;
export declare function getCredentials(): Promise<PushCredentials>;
export declare function getDiagnostics(): Promise<PushDiagnostics>;
export declare function onMessage(listener: OnMessageListener): () => void;
export declare function onNotificationPress(listener: (message: PushMessage) => void): () => void;
//# sourceMappingURL=pushSignal.native.d.ts.map